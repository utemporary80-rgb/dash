import React, { useState } from 'react';
import { 
  BarChart3, 
  Users, 
  FolderOpen, 
  Activity, 
  UserCheck, 
  Clock, 
  ClipboardList, 
  CheckSquare, 
  Settings, 
  FileText, 
  Shield, 
  RefreshCw,
  Star,
  Menu,
  X
} from 'lucide-react';

interface Employee {
  name: string;
  role: string;
  rating: number;
  feedback: string;
}

interface CategoryData {
  category: string;
  quarters: {
    [key: string]: {
      employeeContribution: {
        rating: number;
        feedback: string;
        contributor: string;
      };
      leadFeedback: {
        rating: number;
        feedback: string;
        contributor: string;
      };
      practiceLeadFeedback: {
        rating: number;
        feedback: string;
        contributor: string;
      };
    };
  };
}

const sidebarItems = [
  { icon: BarChart3, label: 'Admin Dashboard', active: true },
  { icon: Users, label: 'Clients' },
  { icon: FolderOpen, label: 'Projects' },
  { icon: Activity, label: 'Change Activity Type' },
  { icon: UserCheck, label: 'Employees' },
  { icon: Clock, label: 'Timesheet Setting' },
  { icon: ClipboardList, label: 'Tasks Allocation' },
  { icon: CheckSquare, label: 'Approvals' },
  { icon: Settings, label: 'Evaluation Setting' },
  { icon: FileText, label: 'Export' },
  { icon: Shield, label: 'Admin Configuration' },
  { icon: RefreshCw, label: 'Role Change' }
];

const StarRating: React.FC<{ rating: number; onRatingChange?: (rating: number) => void }> = ({ 
  rating, 
  onRatingChange 
}) => {
  return (
    <div className="flex space-x-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          className={`w-5 h-5 cursor-pointer transition-colors ${
            star <= rating 
              ? 'fill-yellow-400 text-yellow-400' 
              : 'text-gray-300 hover:text-yellow-300'
          }`}
          onClick={() => onRatingChange && onRatingChange(star)}
        />
      ))}
    </div>
  );
};

const FeedbackCard: React.FC<{
  title: string;
  employee: Employee;
  quarter: string;
  onUpdate?: (employee: Employee) => void;
}> = ({ title, employee, quarter, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempEmployee, setTempEmployee] = useState(employee);

  const handleSave = () => {
    if (onUpdate) onUpdate(tempEmployee);
    setIsEditing(false);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">{title}</h3>
          <p className="text-sm text-gray-600">{employee.name}</p>
          <span className="inline-block bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded mt-2">
            {quarter}
          </span>
        </div>
        <button
          onClick={() => setIsEditing(!isEditing)}
          className="text-sm text-purple-600 hover:text-purple-800 transition-colors"
        >
          {isEditing ? 'Cancel' : 'Edit'}
        </button>
      </div>

      <div className="mb-4">
        <StarRating 
          rating={isEditing ? tempEmployee.rating : employee.rating}
          onRatingChange={isEditing ? (rating) => setTempEmployee({ ...tempEmployee, rating }) : undefined}
        />
        <span className="text-sm text-gray-500 ml-2">Rating: {isEditing ? tempEmployee.rating : employee.rating}</span>
      </div>

      {isEditing ? (
        <div>
          <textarea
            value={tempEmployee.feedback}
            onChange={(e) => setTempEmployee({ ...tempEmployee, feedback: e.target.value })}
            className="w-full p-3 border border-gray-300 rounded-md resize-none h-24 text-sm"
            placeholder="Enter feedback..."
          />
          <div className="flex gap-2 mt-3">
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-purple-600 text-white text-sm rounded-md hover:bg-purple-700 transition-colors"
            >
              Save
            </button>
            <button
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 bg-gray-300 text-gray-700 text-sm rounded-md hover:bg-gray-400 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <p className="text-sm text-gray-700 leading-relaxed">
          {employee.feedback}
        </p>
      )}
    </div>
  );
};

function App() {
  const [selectedQuarters, setSelectedQuarters] = useState<string[]>(['Q2']);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [categoryData, setCategoryData] = useState<CategoryData[]>([
    {
      category: 'Technical Skills',
      quarters: {
        Q1: {
          employeeContribution: { rating: 3, feedback: 'Good start to the year with consistent performance.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 4, feedback: 'Strong leadership qualities emerging.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 4, feedback: 'Good technical contributions to practice.', contributor: 'Shrestha Gupta' }
        },
        Q2: {
          employeeContribution: { rating: 4, feedback: 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 4, feedback: 'Excellent performance this quarter. Shows strong leadership qualities and technical expertise.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 5, feedback: 'Outstanding contribution to the practice. Demonstrates exceptional problem-solving skills.', contributor: 'Shrestha Gupta' }
        },
        Q3: {
          employeeContribution: { rating: 4, feedback: 'Maintained high performance standards throughout the quarter.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 5, feedback: 'Outstanding leadership and team management.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 5, feedback: 'Continues to excel in practice leadership.', contributor: 'Shrestha Gupta' }
        },
        Q4: {
          employeeContribution: { rating: 5, feedback: 'Exceptional performance to close out the year.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 5, feedback: 'Exceptional leadership throughout the year.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 5, feedback: 'Exceptional practice leadership and mentoring.', contributor: 'Shrestha Gupta' }
        }
      }
    },
    {
      category: 'Communication',
      quarters: {
        Q1: {
          employeeContribution: { rating: 4, feedback: 'Good communication with team members.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 4, feedback: 'Clear and effective communication style.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 3, feedback: 'Needs improvement in client communication.', contributor: 'Shrestha Gupta' }
        },
        Q2: {
          employeeContribution: { rating: 4, feedback: 'Improved presentation skills and team collaboration.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 5, feedback: 'Excellent communication and mentoring abilities.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 4, feedback: 'Better client interaction and documentation.', contributor: 'Shrestha Gupta' }
        },
        Q3: {
          employeeContribution: { rating: 5, feedback: 'Outstanding communication across all levels.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 5, feedback: 'Exceptional communication and leadership.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 5, feedback: 'Excellent client management and team communication.', contributor: 'Shrestha Gupta' }
        },
        Q4: {
          employeeContribution: { rating: 5, feedback: 'Consistently excellent communication skills.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 5, feedback: 'Outstanding communication leadership.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 5, feedback: 'Exceptional communication and client relations.', contributor: 'Shrestha Gupta' }
        }
      }
    },
    {
      category: 'Leadership',
      quarters: {
        Q1: {
          employeeContribution: { rating: 3, feedback: 'Developing leadership skills.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 3, feedback: 'Shows potential for leadership roles.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 3, feedback: 'Good team collaboration skills.', contributor: 'Shrestha Gupta' }
        },
        Q2: {
          employeeContribution: { rating: 4, feedback: 'Shows good leadership potential and team collaboration.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 4, feedback: 'Emerging leadership qualities in project management.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 4, feedback: 'Good mentoring of junior team members.', contributor: 'Shrestha Gupta' }
        },
        Q3: {
          employeeContribution: { rating: 4, feedback: 'Strong leadership in project management.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 5, feedback: 'Excellent leadership and decision making.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 4, feedback: 'Strong leadership in technical discussions.', contributor: 'Shrestha Gupta' }
        },
        Q4: {
          employeeContribution: { rating: 5, feedback: 'Excellent leadership and decision making.', contributor: 'Yashvini Sharma' },
          leadFeedback: { rating: 5, feedback: 'Outstanding leadership throughout the year.', contributor: 'Sourabhrata Banerjee' },
          practiceLeadFeedback: { rating: 5, feedback: 'Exceptional leadership and team development.', contributor: 'Shrestha Gupta' }
        }
      }
    }
  ]);

  const [contributionSummary, setContributionSummary] = useState<string>('');

  const toggleQuarter = (quarter: string) => {
    setSelectedQuarters(prev =>
      prev.includes(quarter)
        ? prev.filter(q => q !== quarter)
        : [...prev, quarter]
    );
  };

  const handleRatingUpdate = (categoryIndex: number, quarter: string, newRating: number) => {
    // This function needs to be updated to handle the new structure
    // Will be implemented with specific feedback type
  };

  const handleRatingUpdate2 = (categoryIndex: number, quarter: string, feedbackType: 'employeeContribution' | 'leadFeedback' | 'practiceLeadFeedback', newRating: number) => {
    setCategoryData(prev => prev.map((category, index) => 
      index === categoryIndex 
        ? {
            ...category,
            quarters: {
              ...category.quarters,
              [quarter]: {
                ...category.quarters[quarter],
                [feedbackType]: {
                  ...category.quarters[quarter][feedbackType],
                  rating: newRating
                }
              }
            }
          }
        : category
    ));
  };

  const handleFeedbackUpdate = (categoryIndex: number, quarter: string, feedbackType: 'employeeContribution' | 'leadFeedback' | 'practiceLeadFeedback', newFeedback: string) => {
    setCategoryData(prev => prev.map((category, index) => 
      index === categoryIndex 
        ? {
            ...category,
            quarters: {
              ...category.quarters,
              [quarter]: {
                ...category.quarters[quarter],
                [feedbackType]: {
                  ...category.quarters[quarter][feedbackType],
                  feedback: newFeedback
                }
              }
            }
          }
        : category
    ));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-purple-700 to-purple-800 text-white shadow-lg">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 rounded-md hover:bg-purple-600 transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                <span className="text-purple-700 font-bold text-sm">P</span>
              </div>
              <span className="font-semibold text-lg">Pursuit Software</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm opacity-90">Yashvini Sharma</span>
            <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
              <span className="text-xs font-medium">YS</span>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <div className={`${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transition-transform duration-200 ease-in-out`}>
          <div className="flex justify-between items-center p-4 border-b lg:hidden">
            <span className="font-semibold">Menu</span>
            <button
              onClick={() => setSidebarOpen(false)}
              className="p-2 rounded-md hover:bg-gray-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <nav className="p-4 space-y-1">
            {sidebarItems.map((item, index) => (
              <button
                key={index}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md text-left transition-colors ${
                  item.active
                    ? 'bg-purple-50 text-purple-700 border-r-2 border-purple-600'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-800'
                }`}
              >
                <item.icon className="w-4 h-4" />
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Top Controls */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-gray-700">Year</label>
                <select className="border border-gray-300 rounded-md px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                  <option>2024</option>
                  <option>2023</option>
                </select>
              </div>
              <div className="flex items-center space-x-3">
                {['Q1', 'Q2', 'Q3', 'Q4'].map((quarter) => (
                  <label key={quarter} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedQuarters.includes(quarter)}
                      onChange={() => toggleQuarter(quarter)}
                      className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                    />
                    <span className="text-sm font-medium text-gray-700">{quarter}</span>
                  </label>
                ))}
              </div>
            </div>
            <button className="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700 transition-colors text-sm font-medium">
              Change Status
            </button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Plan</h3>
              <p className="text-2xl font-bold text-gray-800">-</p>
            </div>
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Billability</h3>
              <div className="flex items-center space-x-2">
                <p className="text-2xl font-bold text-gray-800">23.3</p>
                <CheckSquare className="w-5 h-5 text-green-500" />
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Final Percentage</h3>
              <p className="text-2xl font-bold text-gray-800">62.3</p>
            </div>
          </div>

          {/* Tabular Feedback View */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-8 overflow-hidden">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-800">Performance Feedback</h3>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="sticky left-0 bg-gray-50 px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider border-r border-gray-200 min-w-[200px]">
                      Category
                    </th>
                    {selectedQuarters.map((quarter) => (
                      <th key={quarter} colSpan={3} className="px-6 py-4 text-center text-sm font-medium text-gray-500 uppercase tracking-wider border-l border-gray-200">
                        {quarter} 2024
                      </th>
                    ))}
                  </tr>
                  <tr>
                    <th className="sticky left-0 bg-gray-50 px-6 py-2 border-r border-gray-200"></th>
                    {selectedQuarters.map((quarter) => (
                      <React.Fragment key={quarter}>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-l border-gray-200 min-w-[250px]">
                          Employee Contribution
                        </th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-l border-gray-200 min-w-[250px]">
                          Lead Feedback
                        </th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-l border-gray-200 min-w-[250px]">
                          Practice Lead Feedback
                        </th>
                      </React.Fragment>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {categoryData.map((category, categoryIndex) => (
                    <tr key={category.category} className="hover:bg-gray-50">
                      <td className="sticky left-0 bg-white px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 border-r border-gray-200">
                        {category.category}
                      </td>
                      {selectedQuarters.map((quarter) => (
                        <React.Fragment key={quarter}>
                          {/* Employee Contribution */}
                          <td className="px-3 py-4 text-sm text-gray-900 border-l border-gray-200">
                            {category.quarters[quarter] ? (
                              <div className="space-y-3">
                                <div className="flex items-center justify-between">
                                  <StarRating 
                                    rating={category.quarters[quarter].employeeContribution.rating}
                                    onRatingChange={(rating) => handleRatingUpdate2(categoryIndex, quarter, 'employeeContribution', rating)}
                                  />
                                  <span className="text-xs text-gray-500">
                                    {category.quarters[quarter].employeeContribution.contributor}
                                  </span>
                                </div>
                                <div className="max-w-xs">
                                  <textarea
                                    value={category.quarters[quarter].employeeContribution.feedback}
                                    onChange={(e) => handleFeedbackUpdate(categoryIndex, quarter, 'employeeContribution', e.target.value)}
                                    className="w-full p-2 border border-gray-300 rounded text-xs resize-none h-20 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                                    placeholder="Enter employee contribution..."
                                  />
                                </div>
                              </div>
                            ) : (
                              <div className="text-gray-400 text-xs">No data</div>
                            )}
                          </td>
                          
                          {/* Lead Feedback */}
                          <td className="px-3 py-4 text-sm text-gray-900 border-l border-gray-200">
                            {category.quarters[quarter] ? (
                              <div className="space-y-3">
                                <div className="flex items-center justify-between">
                                  <StarRating 
                                    rating={category.quarters[quarter].leadFeedback.rating}
                                    onRatingChange={(rating) => handleRatingUpdate2(categoryIndex, quarter, 'leadFeedback', rating)}
                                  />
                                  <span className="text-xs text-gray-500">
                                    {category.quarters[quarter].leadFeedback.contributor}
                                  </span>
                                </div>
                                <div className="max-w-xs">
                                  <textarea
                                    value={category.quarters[quarter].leadFeedback.feedback}
                                    onChange={(e) => handleFeedbackUpdate(categoryIndex, quarter, 'leadFeedback', e.target.value)}
                                    className="w-full p-2 border border-gray-300 rounded text-xs resize-none h-20 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                                    placeholder="Enter lead feedback..."
                                  />
                                </div>
                              </div>
                            ) : (
                              <div className="text-gray-400 text-xs">No data</div>
                            )}
                          </td>
                          
                          {/* Practice Lead Feedback */}
                          <td className="px-3 py-4 text-sm text-gray-900 border-l border-gray-200">
                            {category.quarters[quarter] ? (
                              <div className="space-y-3">
                                <div className="flex items-center justify-between">
                                  <StarRating 
                                    rating={category.quarters[quarter].practiceLeadFeedback.rating}
                                    onRatingChange={(rating) => handleRatingUpdate2(categoryIndex, quarter, 'practiceLeadFeedback', rating)}
                                  />
                                  <span className="text-xs text-gray-500">
                                    {category.quarters[quarter].practiceLeadFeedback.contributor}
                                  </span>
                                </div>
                                <div className="max-w-xs">
                                  <textarea
                                    value={category.quarters[quarter].practiceLeadFeedback.feedback}
                                    onChange={(e) => handleFeedbackUpdate(categoryIndex, quarter, 'practiceLeadFeedback', e.target.value)}
                                    className="w-full p-2 border border-gray-300 rounded text-xs resize-none h-20 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                                    placeholder="Enter practice lead feedback..."
                                  />
                                </div>
                              </div>
                            ) : (
                              <div className="text-gray-400 text-xs">No data</div>
                            )}
                          </td>
                        </React.Fragment>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Contribution Summary Section */}
          {selectedQuarters.length > 1 && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-8">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-800">Contribution Summary</h3>
                <p className="text-sm text-gray-600 mt-1">Summary across selected quarters: {selectedQuarters.join(', ')}</p>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  {categoryData.map((category) => {
                    const selectedData = selectedQuarters.map(q => category.quarters[q]).filter(Boolean);
                    
                    // Calculate average ratings for each feedback type
                    const avgEmployeeRating = selectedData.length > 0 
                      ? (selectedData.reduce((sum, data) => sum + data.employeeContribution.rating, 0) / selectedData.length).toFixed(1)
                      : '0';
                    const avgLeadRating = selectedData.length > 0 
                      ? (selectedData.reduce((sum, data) => sum + data.leadFeedback.rating, 0) / selectedData.length).toFixed(1)
                      : '0';
                    const avgPracticeRating = selectedData.length > 0 
                      ? (selectedData.reduce((sum, data) => sum + data.practiceLeadFeedback.rating, 0) / selectedData.length).toFixed(1)
                      : '0';
                    
                    const overallAvg = selectedData.length > 0 
                      ? ((parseFloat(avgEmployeeRating) + parseFloat(avgLeadRating) + parseFloat(avgPracticeRating)) / 3).toFixed(1)
                      : '0';
                    
                    return (
                      <div key={category.category} className="p-4 bg-gray-50 rounded-lg">
                        <div className="flex justify-between items-center mb-3">
                          <span className="text-sm font-medium text-gray-700">{category.category}</span>
                          <div className="flex items-center space-x-2">
                            <StarRating rating={Math.round(parseFloat(overallAvg))} />
                            <span className="text-sm text-purple-600">Overall: {overallAvg}</span>
                          </div>
                        </div>
                        <div className="space-y-2 text-xs text-gray-600">
                          <div className="flex justify-between">
                            <span>Employee Contribution:</span>
                            <span className="text-purple-600">{avgEmployeeRating}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Lead Feedback:</span>
                            <span className="text-purple-600">{avgLeadRating}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Practice Lead Feedback:</span>
                            <span className="text-purple-600">{avgPracticeRating}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Overall Contribution Summary
                  </label>
                  <textarea
                    value={contributionSummary}
                    onChange={(e) => setContributionSummary(e.target.value)}
                    placeholder="Add overall contribution summary across selected quarters..."
                    className="w-full p-3 border border-gray-300 rounded-md resize-none h-24 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Additional Notes */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Performance Metrics</h3>
              <div className="space-y-4">
                {categoryData.map((category) => {
                  const selectedData = selectedQuarters.map(q => category.quarters[q]).filter(Boolean);
                  const overallAvg = selectedData.length > 0 
                    ? ((selectedData.reduce((sum, data) => sum + data.employeeContribution.rating + data.leadFeedback.rating + data.practiceLeadFeedback.rating, 0) / selectedData.length) / 3).toFixed(1)
                    : '0';
                  
                  return (
                    <div key={category.category} className="flex justify-between items-center text-sm">
                      <span className="text-gray-600">{category.category}</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-purple-600">Avg: {overallAvg}</span>
                        <span className="text-gray-400">{selectedData.length}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="mt-6">
                <p className="text-sm text-gray-600 mb-2">
                  {selectedQuarters.length > 0 
                    ? `Performance data for ${selectedQuarters.join(', ')}`
                    : 'No quarters selected'
                  }
                </p>
                <textarea
                  placeholder="Add performance notes..."
                  className="w-full p-3 border border-gray-300 rounded-md resize-none h-20 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Additional Notes</h3>
              <p className="text-sm text-gray-600 mb-4">
                There are many variations of passages of Lorem Ipsum available, but the majority
                have suffered alteration in some form by injected humour, or randomised words
                which don't look even slightly believable. If you are going to use a passage of Lorem
                Ipsum, you need to be sure there isn't anything embarrassing...
              </p>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">on {selectedQuarters.length}</span>
                <span className="text-gray-600">done</span>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;